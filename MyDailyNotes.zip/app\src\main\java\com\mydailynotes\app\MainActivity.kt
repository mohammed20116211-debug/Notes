package com.mydailynotes.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import com.mydailynotes.app.alarm.AlarmScheduler
import com.mydailynotes.app.data.local.DailyNotesDatabase
import com.mydailynotes.app.data.repository.HistoryRepository
import com.mydailynotes.app.data.repository.NoteRepository
import com.mydailynotes.app.data.repository.TaskRepository
import com.mydailynotes.app.ui.screens.MainScreen
import com.mydailynotes.app.ui.theme.MyDailyNotesTheme
import com.mydailynotes.app.ui.viewmodel.HistoryViewModel
import com.mydailynotes.app.ui.viewmodel.NoteViewModel
import com.mydailynotes.app.ui.viewmodel.TaskViewModel
import com.mydailynotes.app.ui.viewmodel.ViewModelFactory

class MainActivity : ComponentActivity() {

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        // Notification permission granted or denied
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request POST_NOTIFICATIONS on Android 13+
        checkAndRequestNotificationPermission()

        // Initialize Database and Repositories
        val database = DailyNotesDatabase.getDatabase(applicationContext)
        val alarmScheduler = AlarmScheduler(applicationContext)

        val taskRepository = TaskRepository(database.taskDao(), database.historyDao(), alarmScheduler)
        val noteRepository = NoteRepository(database.noteDao())
        val historyRepository = HistoryRepository(database.historyDao())

        val factory = ViewModelFactory(taskRepository, noteRepository, historyRepository)

        val taskViewModel: TaskViewModel by viewModels { factory }
        val noteViewModel: NoteViewModel by viewModels { factory }
        val historyViewModel: HistoryViewModel by viewModels { factory }

        setContent {
            MyDailyNotesTheme {
                // Ensure RTL layout support for Arabic experience
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        MainScreen(
                            taskViewModel = taskViewModel,
                            noteViewModel = noteViewModel,
                            historyViewModel = historyViewModel
                        )
                    }
                }
            }
        }
    }

    private fun checkAndRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
