package com.mydailynotes.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

class MyDailyNotesApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // 1. Channel for Start Alarm (Call / Loud Alarm Style)
            val startAlarmChannel = NotificationChannel(
                CHANNEL_START_ALARM,
                "تنبيهات بداية المهام",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة إشعارات بداية المهمة بصوت رنين مميز وتنبيه عالي الأهمية"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 1000, 500, 1000, 500)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setBypassDnd(true)
            }

            // 2. Channel for End Alarm (Short Chime Style)
            val endSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val endAlarmChannel = NotificationChannel(
                CHANNEL_END_ALARM,
                "تنبيهات نهاية المهام",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة إشعارات انتهاء وقت المهمة بنغمة قصيرة تشبه صوت الرسالة"
                enableVibration(true)
                setSound(endSoundUri, audioAttributes)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }

            notificationManager.createNotificationChannel(startAlarmChannel)
            notificationManager.createNotificationChannel(endAlarmChannel)
        }
    }

    companion object {
        const val CHANNEL_START_ALARM = "channel_start_task_alarm"
        const val CHANNEL_END_ALARM = "channel_end_task_alarm"
    }
}
