package com.mydailynotes.app.alarm

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class AlarmDismissReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(AlarmScheduler.EXTRA_TASK_ID, -1L)
        Log.d(TAG, "Dismissing alarm sound and notification for taskId: $taskId")

        // Stop Foreground Audio Service
        val serviceIntent = Intent(context, AlarmAudioService::class.java)
        context.stopService(serviceIntent)

        // Cancel notification
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (taskId != -1L) {
            notificationManager.cancel(taskId.toInt())
        }
        notificationManager.cancel(AlarmAudioService.FOREGROUND_NOTIFICATION_ID)
    }

    companion object {
        private const val TAG = "AlarmDismissReceiver"
        const val ACTION_DISMISS_ALARM = "com.mydailynotes.app.ACTION_DISMISS_ALARM"
    }
}
