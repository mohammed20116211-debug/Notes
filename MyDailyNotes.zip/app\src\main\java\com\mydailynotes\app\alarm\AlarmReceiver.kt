package com.mydailynotes.app.alarm

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.mydailynotes.app.MainActivity
import com.mydailynotes.app.MyDailyNotesApp
import com.mydailynotes.app.R
import com.mydailynotes.app.data.local.DailyNotesDatabase
import com.mydailynotes.app.data.local.entity.HistoryEntity
import com.mydailynotes.app.data.model.HistoryActionType
import com.mydailynotes.app.data.model.TaskStatus
import com.mydailynotes.app.ui.screens.alarm.AlarmAlertActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(AlarmScheduler.EXTRA_TASK_ID, -1L)
        val taskTitle = intent.getStringExtra(AlarmScheduler.EXTRA_TASK_TITLE) ?: "مهمة مجدولة"
        val startTimeStr = intent.getStringExtra(AlarmScheduler.EXTRA_START_TIME) ?: ""
        val endTimeStr = intent.getStringExtra(AlarmScheduler.EXTRA_END_TIME) ?: ""

        Log.d(TAG, "Alarm received: action=${intent.action}, taskId=$taskId, title=$taskTitle")

        when (intent.action) {
            AlarmScheduler.ACTION_START_ALARM -> {
                handleStartAlarm(context, taskId, taskTitle, startTimeStr, endTimeStr)
            }
            AlarmScheduler.ACTION_END_ALARM -> {
                handleEndAlarm(context, taskId, taskTitle, endTimeStr)
            }
        }
    }

    private fun handleStartAlarm(
        context: Context,
        taskId: Long,
        taskTitle: String,
        startTimeStr: String,
        endTimeStr: String
    ) {
        // 1. Start Audio Service for continuous incoming-call style ringing
        val audioIntent = Intent(context, AlarmAudioService::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_TASK_ID, taskId)
            putExtra(AlarmScheduler.EXTRA_TASK_TITLE, taskTitle)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(audioIntent)
        } else {
            context.startService(audioIntent)
        }

        // 2. Prepare Full Screen Intent to AlarmAlertActivity
        val fullScreenIntent = Intent(context, AlarmAlertActivity::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_TASK_ID, taskId)
            putExtra(AlarmScheduler.EXTRA_TASK_TITLE, taskTitle)
            putExtra(AlarmScheduler.EXTRA_START_TIME, startTimeStr)
            putExtra(AlarmScheduler.EXTRA_END_TIME, endTimeStr)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            taskId.toInt(),
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Stop Sound Action
        val stopIntent = Intent(context, AlarmDismissReceiver::class.java).apply {
            action = AlarmDismissReceiver.ACTION_DISMISS_ALARM
            putExtra(AlarmScheduler.EXTRA_TASK_ID, taskId)
        }
        val stopPendingIntent = PendingIntent.getBroadcast(
            context,
            taskId.toInt() + 10000,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Open App Action
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(AlarmScheduler.EXTRA_TASK_ID, taskId)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            taskId.toInt() + 20000,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, MyDailyNotesApp.CHANNEL_START_ALARM)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(context.getString(R.string.start_alarm_title))
            .setContentText("$taskTitle\n${context.getString(R.string.start_time)}: $startTimeStr")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "${context.getString(R.string.start_alarm_subtitle)}\n" +
                "المهمة: $taskTitle\n" +
                "التوقيت: $startTimeStr"
            ))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                context.getString(R.string.stop_sound),
                stopPendingIntent
            )
            .addAction(
                android.R.drawable.ic_menu_info_details,
                context.getString(R.string.open_details),
                openPendingIntent
            )
            .setAutoCancel(false)
            .setOngoing(true)
            .build()

        notificationManager.notify(taskId.toInt(), notification)

        // Update task status to IN_PROGRESS in background
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = DailyNotesDatabase.getDatabase(context)
                val taskEntity = db.taskDao().getTaskById(taskId)
                if (taskEntity != null && !taskEntity.isCompleted) {
                    db.taskDao().updateTask(
                        taskEntity.copy(
                            status = TaskStatus.IN_PROGRESS,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error updating task status on start alarm: ${e.message}")
            }
        }
    }

    private fun handleEndAlarm(
        context: Context,
        taskId: Long,
        taskTitle: String,
        endTimeStr: String
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(AlarmScheduler.EXTRA_TASK_ID, taskId)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            (taskId + 50000).toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Distinct short chime sound
        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, MyDailyNotesApp.CHANNEL_END_ALARM)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(context.getString(R.string.end_alarm_title))
            .setContentText("$taskTitle (${context.getString(R.string.end_time)}: $endTimeStr)")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "${context.getString(R.string.end_alarm_title)}:\n$taskTitle\nانتهى الوقت المخصص للمهمة."
            ))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setSound(soundUri)
            .setContentIntent(openPendingIntent)
            .setAutoCancel(true)
            .build()

        notificationManager.notify((taskId + 30000).toInt(), notification)

        // Check if task is not completed, then mark as OVERDUE and log in history
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = DailyNotesDatabase.getDatabase(context)
                val taskEntity = db.taskDao().getTaskById(taskId)
                if (taskEntity != null && !taskEntity.isCompleted) {
                    db.taskDao().updateTask(
                        taskEntity.copy(
                            status = TaskStatus.OVERDUE,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    // Log in History
                    db.historyDao().insertHistory(
                        HistoryEntity(
                            taskId = taskId,
                            taskTitle = taskTitle,
                            actionType = HistoryActionType.EXPIRED,
                            timestamp = System.currentTimeMillis(),
                            details = "انتهى وقت المهمة ولم يتم إنجازها"
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error handling end alarm status update: ${e.message}")
            }
        }
    }

    companion object {
        private const val TAG = "AlarmReceiver"
    }
}
