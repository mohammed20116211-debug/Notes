package com.mydailynotes.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.mydailynotes.app.data.model.Task
import java.time.LocalDateTime
import java.time.ZoneId

class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun scheduleTaskAlarms(task: Task) {
        val now = LocalDateTime.now()

        // 1. Schedule Start Alarm (Unique ID: task.id * 2)
        if (task.isStartAlarmEnabled && !task.isCompleted) {
            val startDateTime = task.startDateTime
            if (startDateTime.isAfter(now)) {
                val triggerEpochMilli = startDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val intent = Intent(context, AlarmReceiver::class.java).apply {
                    action = ACTION_START_ALARM
                    putExtra(EXTRA_TASK_ID, task.id)
                    putExtra(EXTRA_TASK_TITLE, task.title)
                    putExtra(EXTRA_START_TIME, task.formattedTimeRange())
                    putExtra(EXTRA_END_TIME, task.endTime.toString())
                }
                val requestCode = (task.id * 2).toInt()
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                setExactAlarm(triggerEpochMilli, pendingIntent)
                Log.d(TAG, "Scheduled Start Alarm for task '${task.title}' at $startDateTime (reqCode: $requestCode)")
            }
        }

        // 2. Schedule End Alarm (Unique ID: task.id * 2 + 1)
        if (task.isEndAlarmEnabled && !task.isCompleted) {
            val endDateTime = task.endDateTime
            if (endDateTime.isAfter(now)) {
                val triggerEpochMilli = endDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val intent = Intent(context, AlarmReceiver::class.java).apply {
                    action = ACTION_END_ALARM
                    putExtra(EXTRA_TASK_ID, task.id)
                    putExtra(EXTRA_TASK_TITLE, task.title)
                    putExtra(EXTRA_END_TIME, task.endTime.toString())
                }
                val requestCode = (task.id * 2 + 1).toInt()
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                setExactAlarm(triggerEpochMilli, pendingIntent)
                Log.d(TAG, "Scheduled End Alarm for task '${task.title}' at $endDateTime (reqCode: $requestCode)")
            }
        }
    }

    fun cancelTaskAlarms(taskId: Long) {
        // Cancel Start Alarm
        val startIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_START_ALARM
        }
        val startReqCode = (taskId * 2).toInt()
        val startPendingIntent = PendingIntent.getBroadcast(
            context,
            startReqCode,
            startIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (startPendingIntent != null) {
            alarmManager.cancel(startPendingIntent)
            startPendingIntent.cancel()
        }

        // Cancel End Alarm
        val endIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_END_ALARM
        }
        val endReqCode = (taskId * 2 + 1).toInt()
        val endPendingIntent = PendingIntent.getBroadcast(
            context,
            endReqCode,
            endIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (endPendingIntent != null) {
            alarmManager.cancel(endPendingIntent)
            endPendingIntent.cancel()
        }
        Log.d(TAG, "Cancelled alarms for taskId: $taskId")
    }

    private fun setExactAlarm(triggerEpochMilli: Long, pendingIntent: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerEpochMilli,
                        pendingIntent
                    )
                } else {
                    // Fallback if exact alarm permission is not granted
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerEpochMilli,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerEpochMilli,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException while scheduling exact alarm: ${e.message}")
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerEpochMilli, pendingIntent)
        }
    }

    companion object {
        private const val TAG = "AlarmScheduler"
        const val ACTION_START_ALARM = "com.mydailynotes.app.ACTION_START_ALARM"
        const val ACTION_END_ALARM = "com.mydailynotes.app.ACTION_END_ALARM"
        const val EXTRA_TASK_ID = "extra_task_id"
        const val EXTRA_TASK_TITLE = "extra_task_title"
        const val EXTRA_START_TIME = "extra_start_time"
        const val EXTRA_END_TIME = "extra_end_time"
    }
}
