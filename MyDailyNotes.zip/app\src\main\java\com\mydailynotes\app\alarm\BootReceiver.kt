package com.mydailynotes.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.mydailynotes.app.data.local.DailyNotesDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d(TAG, "BootReceiver triggered with action: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = DailyNotesDatabase.getDatabase(context)
                    val scheduler = AlarmScheduler(context)

                    val now = LocalDate.now()
                    val currentTime = LocalTime.now()

                    val futureTasks = db.taskDao().getFutureActiveTasks(now, currentTime)
                    Log.d(TAG, "Rescheduling ${futureTasks.size} active tasks after boot/update")

                    for (taskEntity in futureTasks) {
                        scheduler.scheduleTaskAlarms(taskEntity.toDomainModel())
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error rescheduling alarms after boot: ${e.message}")
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
