package com.mydailynotes.app.data.local

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mydailynotes.app.data.model.Category
import com.mydailynotes.app.data.model.HistoryActionType
import com.mydailynotes.app.data.model.Priority
import com.mydailynotes.app.data.model.RecurringType
import com.mydailynotes.app.data.model.TaskStatus
import java.time.LocalDate
import java.time.LocalTime

class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromLocalDate(date: LocalDate?): String? = date?.toString()

    @TypeConverter
    fun toLocalDate(value: String?): LocalDate? = value?.let { LocalDate.parse(it) }

    @TypeConverter
    fun fromLocalTime(time: LocalTime?): String? = time?.toString()

    @TypeConverter
    fun toLocalTime(value: String?): LocalTime? = value?.let { LocalTime.parse(it) }

    @TypeConverter
    fun fromCategory(category: Category?): String? = category?.name

    @TypeConverter
    fun toCategory(value: String?): Category? = value?.let { Category.valueOf(it) }

    @TypeConverter
    fun fromPriority(priority: Priority?): String? = priority?.name

    @TypeConverter
    fun toPriority(value: String?): Priority? = value?.let { Priority.valueOf(it) }

    @TypeConverter
    fun fromTaskStatus(status: TaskStatus?): String? = status?.name

    @TypeConverter
    fun toTaskStatus(value: String?): TaskStatus? = value?.let { TaskStatus.valueOf(it) }

    @TypeConverter
    fun fromRecurringType(type: RecurringType?): String? = type?.name

    @TypeConverter
    fun toRecurringType(value: String?): RecurringType? = value?.let { RecurringType.valueOf(it) }

    @TypeConverter
    fun fromHistoryActionType(type: HistoryActionType?): String? = type?.name

    @TypeConverter
    fun toHistoryActionType(value: String?): HistoryActionType? = value?.let { HistoryActionType.valueOf(it) }

    @TypeConverter
    fun fromIntList(list: List<Int>?): String? = gson.toJson(list ?: emptyList<Int>())

    @TypeConverter
    fun toIntList(value: String?): List<Int> {
        if (value.isNullOrEmpty()) return emptyList()
        val type = object : TypeToken<List<Int>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }
}
