package com.mydailynotes.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.mydailynotes.app.data.local.dao.HistoryDao
import com.mydailynotes.app.data.local.dao.NoteDao
import com.mydailynotes.app.data.local.dao.TaskDao
import com.mydailynotes.app.data.local.entity.HistoryEntity
import com.mydailynotes.app.data.local.entity.NoteEntity
import com.mydailynotes.app.data.local.entity.TaskEntity

@Database(
    entities = [
        TaskEntity::class,
        NoteEntity::class,
        HistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class DailyNotesDatabase : RoomDatabase() {

    abstract fun taskDao(): TaskDao
    abstract fun noteDao(): NoteDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: DailyNotesDatabase? = null

        fun getDatabase(context: Context): DailyNotesDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DailyNotesDatabase::class.java,
                    "daily_notes_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
