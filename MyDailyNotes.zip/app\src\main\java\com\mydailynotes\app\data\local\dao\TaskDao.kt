package com.mydailynotes.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.mydailynotes.app.data.local.entity.TaskEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface TaskDao {

    @Query("SELECT * FROM tasks WHERE startDate = :date ORDER BY startTime ASC")
    fun getTasksForDate(date: LocalDate): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks ORDER BY startDate ASC, startTime ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: Long): TaskEntity?

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 AND (startDate > :currentDate OR (startDate = :currentDate AND startTime >= :currentTime))")
    suspend fun getFutureActiveTasks(currentDate: LocalDate, currentTime: java.time.LocalTime): List<TaskEntity>

    @Query("SELECT DISTINCT startDate FROM tasks")
    fun getAllDatesWithTasks(): Flow<List<LocalDate>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 1 ORDER BY startDate DESC, startTime DESC")
    fun getCompletedTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' ORDER BY startDate DESC, startTime DESC")
    fun searchTasks(query: String): Flow<List<TaskEntity>>

    @Query("SELECT COUNT(*) FROM tasks WHERE startDate = :date")
    fun getTotalTasksCountForDate(date: LocalDate): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE startDate = :date AND isCompleted = 1")
    fun getCompletedTasksCountForDate(date: LocalDate): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tasks: List<TaskEntity>)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Long)

    @Query("DELETE FROM tasks")
    suspend fun deleteAllTasks()
}
