package com.mydailynotes.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mydailynotes.app.data.model.HistoryActionType
import com.mydailynotes.app.data.model.HistoryItem

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskId: Long,
    val taskTitle: String,
    val actionType: HistoryActionType,
    val timestamp: Long,
    val details: String
) {
    fun toDomainModel(): HistoryItem = HistoryItem(
        id = id,
        taskId = taskId,
        taskTitle = taskTitle,
        actionType = actionType,
        timestamp = timestamp,
        details = details
    )

    companion object {
        fun fromDomainModel(item: HistoryItem): HistoryEntity = HistoryEntity(
            id = item.id,
            taskId = item.taskId,
            taskTitle = item.taskTitle,
            actionType = item.actionType,
            timestamp = item.timestamp,
            details = item.details
        )
    }
}
