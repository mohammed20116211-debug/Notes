package com.mydailynotes.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mydailynotes.app.data.model.Note
import java.time.LocalDate

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val date: LocalDate,
    val colorTag: Long,
    val isPinned: Boolean,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomainModel(): Note = Note(
        id = id,
        title = title,
        content = content,
        date = date,
        colorTag = colorTag,
        isPinned = isPinned,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    companion object {
        fun fromDomainModel(note: Note): NoteEntity = NoteEntity(
            id = note.id,
            title = note.title,
            content = note.content,
            date = note.date,
            colorTag = note.colorTag,
            isPinned = note.isPinned,
            createdAt = note.createdAt,
            updatedAt = note.updatedAt
        )
    }
}
