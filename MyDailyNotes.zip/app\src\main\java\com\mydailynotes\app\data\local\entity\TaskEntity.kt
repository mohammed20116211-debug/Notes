package com.mydailynotes.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mydailynotes.app.data.model.Category
import com.mydailynotes.app.data.model.Priority
import com.mydailynotes.app.data.model.RecurringType
import com.mydailynotes.app.data.model.Task
import com.mydailynotes.app.data.model.TaskStatus
import java.time.LocalDate
import java.time.LocalTime

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val startDate: LocalDate,
    val endDate: LocalDate,
    val startTime: LocalTime,
    val endTime: LocalTime,
    val durationMinutes: Long,
    val category: Category,
    val priority: Priority,
    val status: TaskStatus,
    val isCompleted: Boolean,
    val isRecurring: Boolean,
    val recurringType: RecurringType,
    val recurringDays: List<Int>,
    val isStartAlarmEnabled: Boolean,
    val isEndAlarmEnabled: Boolean,
    val ringtoneUri: String?,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomainModel(): Task = Task(
        id = id,
        title = title,
        description = description,
        startDate = startDate,
        endDate = endDate,
        startTime = startTime,
        endTime = endTime,
        durationMinutes = durationMinutes,
        category = category,
        priority = priority,
        status = status,
        isCompleted = isCompleted,
        isRecurring = isRecurring,
        recurringType = recurringType,
        recurringDays = recurringDays,
        isStartAlarmEnabled = isStartAlarmEnabled,
        isEndAlarmEnabled = isEndAlarmEnabled,
        ringtoneUri = ringtoneUri,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    companion object {
        fun fromDomainModel(task: Task): TaskEntity = TaskEntity(
            id = task.id,
            title = task.title,
            description = task.description,
            startDate = task.startDate,
            endDate = task.endDate,
            startTime = task.startTime,
            endTime = task.endTime,
            durationMinutes = task.durationMinutes,
            category = task.category,
            priority = task.priority,
            status = task.status,
            isCompleted = task.isCompleted,
            isRecurring = task.isRecurring,
            recurringType = task.recurringType,
            recurringDays = task.recurringDays,
            isStartAlarmEnabled = task.isStartAlarmEnabled,
            isEndAlarmEnabled = task.isEndAlarmEnabled,
            ringtoneUri = task.ringtoneUri,
            createdAt = task.createdAt,
            updatedAt = task.updatedAt
        )
    }
}
