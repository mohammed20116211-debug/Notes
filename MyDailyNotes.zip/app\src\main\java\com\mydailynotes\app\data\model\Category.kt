package com.mydailynotes.app.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class Category(val titleAr: String, val titleEn: String, val colorValue: Long) {
    WORK("العمل", "Work", 0xFF0288D1),
    STUDY("الدراسة", "Study", 0xFF8B5CF6),
    PERSONAL("المواعيد الشخصية", "Personal", 0xFFEC4899),
    HEALTH("الصحة", "Health", 0xFF10B981),
    OTHER("أخرى", "Other", 0xFF64748B);

    fun getColor(): Color = Color(colorValue)

    fun getIcon(): ImageVector = when (this) {
        WORK -> Icons.Default.Work
        STUDY -> Icons.Default.School
        PERSONAL -> Icons.Default.Person
        HEALTH -> Icons.Default.Favorite
        OTHER -> Icons.Default.Assignment
    }
}
