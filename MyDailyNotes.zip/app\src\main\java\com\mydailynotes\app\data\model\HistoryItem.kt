package com.mydailynotes.app.data.model

import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class HistoryActionType(val titleAr: String, val titleEn: String, val colorValue: Long) {
    CREATED("إنشاء مهمة", "Task Created", 0xFF0288D1),
    COMPLETED("إنجاز مهمة", "Task Completed", 0xFF10B981),
    POSTPONED("تأجيل إلى الغد", "Task Postponed", 0xFFF59E0B),
    EDITED("تعديل مهمة", "Task Edited", 0xFF8B5CF6),
    DELETED("حذف مهمة", "Task Deleted", 0xFFEF4444),
    EXPIRED("انتهى وقتها", "Task Expired", 0xFF64748B)
}

data class HistoryItem(
    val id: Long = 0,
    val taskId: Long,
    val taskTitle: String,
    val actionType: HistoryActionType,
    val timestamp: Long = System.currentTimeMillis(),
    val details: String = ""
) {
    fun formattedDateTime(): String {
        val dt = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault())
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd  hh:mm a", Locale.getDefault())
        return dt.format(formatter)
    }
}
