package com.mydailynotes.app.data.model

import java.time.LocalDate

data class Note(
    val id: Long = 0,
    val title: String,
    val content: String,
    val date: LocalDate = LocalDate.now(),
    val colorTag: Long = 0xFFE0F2FE, // Default sky blue tint
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
