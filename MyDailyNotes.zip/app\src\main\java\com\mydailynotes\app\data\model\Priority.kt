package com.mydailynotes.app.data.model

import androidx.compose.ui.graphics.Color

enum class Priority(val titleAr: String, val titleEn: String, val colorValue: Long) {
    LOW("منخفضة", "Low", 0xFF10B981),
    MEDIUM("متوسطة", "Medium", 0xFFF59E0B),
    HIGH("عالية", "High", 0xFFEF4444);

    fun getColor(): Color = Color(colorValue)
}
