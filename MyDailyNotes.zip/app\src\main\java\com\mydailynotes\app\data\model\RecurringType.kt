package com.mydailynotes.app.data.model

enum class RecurringType(val titleAr: String, val titleEn: String) {
    NONE("بدون تكرار", "No Repeat"),
    DAILY("يومياً", "Daily"),
    WEEKLY("أسبوعياً", "Weekly"),
    MONTHLY("شهرياً", "Monthly"),
    CUSTOM_DAYS("أيام محددة من الأسبوع", "Specific Days")
}
