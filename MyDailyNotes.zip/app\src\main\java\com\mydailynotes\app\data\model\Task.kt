package com.mydailynotes.app.data.model

import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Task(
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val startDate: LocalDate,
    val endDate: LocalDate = startDate,
    val startTime: LocalTime,
    val endTime: LocalTime,
    val durationMinutes: Long = calculateDurationInMinutes(startDate, startTime, endDate, endTime),
    val category: Category = Category.WORK,
    val priority: Priority = Priority.MEDIUM,
    val status: TaskStatus = TaskStatus.NOT_STARTED,
    val isCompleted: Boolean = false,
    val isRecurring: Boolean = false,
    val recurringType: RecurringType = RecurringType.NONE,
    val recurringDays: List<Int> = emptyList(), // 1 = Monday ... 7 = Sunday
    val isStartAlarmEnabled: Boolean = true,
    val isEndAlarmEnabled: Boolean = true,
    val ringtoneUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val startDateTime: LocalDateTime
        get() = LocalDateTime.of(startDate, startTime)

    val endDateTime: LocalDateTime
        get() = LocalDateTime.of(endDate, endTime)

    /**
     * Determines the automatic status if task is not manually marked completed:
     * - Before start time -> NOT_STARTED
     * - Between start and end time -> IN_PROGRESS
     * - After end time without completion -> OVERDUE
     */
    fun computeDynamicStatus(now: LocalDateTime = LocalDateTime.now()): TaskStatus {
        if (isCompleted) return TaskStatus.COMPLETED
        return when {
            now.isBefore(startDateTime) -> TaskStatus.NOT_STARTED
            now.isAfter(endDateTime) -> TaskStatus.OVERDUE
            else -> TaskStatus.IN_PROGRESS
        }
    }

    fun formattedTimeRange(): String {
        val timeFormatter = DateTimeFormatter.ofPattern("hh:mm a", Locale.getDefault())
        val startStr = startTime.format(timeFormatter)
        val endStr = endTime.format(timeFormatter)
        return if (startDate == endDate) {
            "$startStr - $endStr"
        } else {
            val dateFormatter = DateTimeFormatter.ofPattern("dd/MM", Locale.getDefault())
            "$startStr - $endStr (${endDate.format(dateFormatter)})"
        }
    }

    fun formattedDuration(): String {
        val totalMinutes = durationMinutes
        val hours = totalMinutes / 60
        val minutes = totalMinutes % 60
        return when {
            hours > 0 && minutes > 0 -> {
                val hourUnit = if (hours == 1L) "ساعة" else if (hours == 2L) "ساعتان" else "$hours ساعات"
                val minUnit = "$minutes دقيقة"
                "$hourUnit و $minUnit"
            }
            hours > 0 -> {
                if (hours == 1L) "ساعة واحدة" else if (hours == 2L) "ساعتان" else "$hours ساعات"
            }
            else -> "$minutes دقيقة"
        }
    }

    companion object {
        fun calculateDurationInMinutes(
            startDate: LocalDate,
            startTime: LocalTime,
            endDate: LocalDate,
            endTime: LocalTime
        ): Long {
            val start = LocalDateTime.of(startDate, startTime)
            val end = LocalDateTime.of(endDate, endTime)
            val minutes = Duration.between(start, end).toMinutes()
            return if (minutes < 0) 0 else minutes
        }
    }
}
