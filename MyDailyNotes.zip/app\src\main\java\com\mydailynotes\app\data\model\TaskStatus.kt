package com.mydailynotes.app.data.model

import androidx.compose.ui.graphics.Color

enum class TaskStatus(val titleAr: String, val titleEn: String, val colorValue: Long) {
    NOT_STARTED("لم تبدأ", "Not Started", 0xFF64748B),
    IN_PROGRESS("قيد التنفيذ", "In Progress", 0xFF0288D1),
    COMPLETED("مكتملة", "Completed", 0xFF10B981),
    OVERDUE("انتهى وقتها ولم تُنجز", "Expired & Incomplete", 0xFFEF4444);

    fun getColor(): Color = Color(colorValue)
}
