package com.mydailynotes.app.data.repository

import com.mydailynotes.app.data.local.dao.HistoryDao
import com.mydailynotes.app.data.local.entity.HistoryEntity
import com.mydailynotes.app.data.model.HistoryItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class HistoryRepository(private val historyDao: HistoryDao) {

    fun getRecentHistory(limit: Int = 100): Flow<List<HistoryItem>> {
        return historyDao.getRecentHistory(limit).map { list ->
            list.map { it.toDomainModel() }
        }
    }

    suspend fun addHistory(item: HistoryItem): Long {
        val id = historyDao.insertHistory(HistoryEntity.fromDomainModel(item))
        historyDao.trimOldHistory(100)
        return id
    }

    suspend fun clearHistory() {
        historyDao.clearHistory()
    }
}
