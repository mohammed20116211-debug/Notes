package com.mydailynotes.app.data.repository

import com.mydailynotes.app.data.local.dao.NoteDao
import com.mydailynotes.app.data.local.entity.NoteEntity
import com.mydailynotes.app.data.model.Note
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

class NoteRepository(private val noteDao: NoteDao) {

    fun getAllNotes(): Flow<List<Note>> {
        return noteDao.getAllNotes().map { list -> list.map { it.toDomainModel() } }
    }

    fun getNotesForDate(date: LocalDate): Flow<List<Note>> {
        return noteDao.getNotesForDate(date).map { list -> list.map { it.toDomainModel() } }
    }

    fun searchNotes(query: String): Flow<List<Note>> {
        return noteDao.searchNotes(query).map { list -> list.map { it.toDomainModel() } }
    }

    suspend fun addNote(note: Note): Long {
        return noteDao.insertNote(NoteEntity.fromDomainModel(note))
    }

    suspend fun updateNote(note: Note) {
        noteDao.updateNote(NoteEntity.fromDomainModel(note.copy(updatedAt = System.currentTimeMillis())))
    }

    suspend fun deleteNote(note: Note) {
        noteDao.deleteNote(NoteEntity.fromDomainModel(note))
    }
}
