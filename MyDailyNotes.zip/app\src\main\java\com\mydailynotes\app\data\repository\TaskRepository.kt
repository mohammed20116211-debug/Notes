package com.mydailynotes.app.data.repository

import com.mydailynotes.app.alarm.AlarmScheduler
import com.mydailynotes.app.data.local.dao.HistoryDao
import com.mydailynotes.app.data.local.dao.TaskDao
import com.mydailynotes.app.data.local.entity.HistoryEntity
import com.mydailynotes.app.data.local.entity.TaskEntity
import com.mydailynotes.app.data.model.HistoryActionType
import com.mydailynotes.app.data.model.Task
import com.mydailynotes.app.data.model.TaskStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

class TaskRepository(
    private val taskDao: TaskDao,
    private val historyDao: HistoryDao,
    private val alarmScheduler: AlarmScheduler
) {

    fun getTasksForDate(date: LocalDate): Flow<List<Task>> {
        return taskDao.getTasksForDate(date).map { list ->
            list.map { it.toDomainModel() }
        }
    }

    fun getAllTasks(): Flow<List<Task>> {
        return taskDao.getAllTasks().map { list ->
            list.map { it.toDomainModel() }
        }
    }

    fun getCompletedTasks(): Flow<List<Task>> {
        return taskDao.getCompletedTasks().map { list ->
            list.map { it.toDomainModel() }
        }
    }

    fun getAllDatesWithTasks(): Flow<List<LocalDate>> {
        return taskDao.getAllDatesWithTasks()
    }

    fun searchTasks(query: String): Flow<List<Task>> {
        return taskDao.searchTasks(query).map { list ->
            list.map { it.toDomainModel() }
        }
    }

    fun getTotalCountForDate(date: LocalDate): Flow<Int> = taskDao.getTotalTasksCountForDate(date)

    fun getCompletedCountForDate(date: LocalDate): Flow<Int> = taskDao.getCompletedTasksCountForDate(date)

    suspend fun addTask(task: Task): Long {
        val entity = TaskEntity.fromDomainModel(task)
        val generatedId = taskDao.insertTask(entity)
        val savedTask = task.copy(id = generatedId)

        // Schedule start & end alarms
        alarmScheduler.scheduleTaskAlarms(savedTask)

        // Log operation in History
        historyDao.insertHistory(
            HistoryEntity(
                taskId = generatedId,
                taskTitle = task.title,
                actionType = HistoryActionType.CREATED,
                timestamp = System.currentTimeMillis(),
                details = "تم إنشاء المهمة في تاريخ ${task.startDate}"
            )
        )
        return generatedId
    }

    suspend fun updateTask(task: Task) {
        // Cancel old alarms
        alarmScheduler.cancelTaskAlarms(task.id)

        // Save updated task
        val entity = TaskEntity.fromDomainModel(task.copy(updatedAt = System.currentTimeMillis()))
        taskDao.updateTask(entity)

        // Reschedule alarms if not completed
        if (!task.isCompleted) {
            alarmScheduler.scheduleTaskAlarms(task)
        }

        // Log operation
        historyDao.insertHistory(
            HistoryEntity(
                taskId = task.id,
                taskTitle = task.title,
                actionType = HistoryActionType.EDITED,
                timestamp = System.currentTimeMillis(),
                details = "تم تعديل مواعيد/بيانات المهمة"
            )
        )
    }

    suspend fun deleteTask(task: Task) {
        // Cancel alarms
        alarmScheduler.cancelTaskAlarms(task.id)

        // Delete from database
        taskDao.deleteTaskById(task.id)

        // Log operation
        historyDao.insertHistory(
            HistoryEntity(
                taskId = task.id,
                taskTitle = task.title,
                actionType = HistoryActionType.DELETED,
                timestamp = System.currentTimeMillis(),
                details = "تم حذف المهمة وإلغاء تنبيهاتها"
            )
        )
    }

    suspend fun toggleTaskCompletion(task: Task, isCompleted: Boolean) {
        if (isCompleted) {
            // Cancel future alarms
            alarmScheduler.cancelTaskAlarms(task.id)

            val updated = task.copy(
                isCompleted = true,
                status = TaskStatus.COMPLETED,
                updatedAt = System.currentTimeMillis()
            )
            taskDao.updateTask(TaskEntity.fromDomainModel(updated))

            // Log completion
            historyDao.insertHistory(
                HistoryEntity(
                    taskId = task.id,
                    taskTitle = task.title,
                    actionType = HistoryActionType.COMPLETED,
                    timestamp = System.currentTimeMillis(),
                    details = "تم إنجاز المهمة بنجاح"
                )
            )
        } else {
            // Restore task
            val newStatus = task.computeDynamicStatus()
            val restored = task.copy(
                isCompleted = false,
                status = newStatus,
                updatedAt = System.currentTimeMillis()
            )
            taskDao.updateTask(TaskEntity.fromDomainModel(restored))

            // Reschedule alarms if future
            alarmScheduler.scheduleTaskAlarms(restored)

            historyDao.insertHistory(
                HistoryEntity(
                    taskId = task.id,
                    taskTitle = task.title,
                    actionType = HistoryActionType.EDITED,
                    timestamp = System.currentTimeMillis(),
                    details = "تم إلغاء إنجاز المهمة وإعادتها للجدول"
                )
            )
        }
    }

    suspend fun postponeTaskToTomorrow(task: Task) {
        // Cancel old alarms
        alarmScheduler.cancelTaskAlarms(task.id)

        // Calculate new dates preserving duration
        val newStartDate = task.startDate.plusDays(1)
        val daysSpan = java.time.temporal.ChronoUnit.DAYS.between(task.startDate, task.endDate)
        val newEndDate = newStartDate.plusDays(daysSpan)

        val postponed = task.copy(
            startDate = newStartDate,
            endDate = newEndDate,
            status = TaskStatus.NOT_STARTED,
            isCompleted = false,
            updatedAt = System.currentTimeMillis()
        )

        taskDao.updateTask(TaskEntity.fromDomainModel(postponed))

        // Schedule new alarms
        alarmScheduler.scheduleTaskAlarms(postponed)

        // Log operation
        historyDao.insertHistory(
            HistoryEntity(
                taskId = task.id,
                taskTitle = task.title,
                actionType = HistoryActionType.POSTPONED,
                timestamp = System.currentTimeMillis(),
                details = "تم تأجيل المهمة إلى $newStartDate بنفس التوقيت والمدة"
            )
        )
    }

    suspend fun updateTaskStatus(taskId: Long, newStatus: TaskStatus) {
        val task = taskDao.getTaskById(taskId)
        if (task != null) {
            taskDao.updateTask(task.copy(status = newStatus, updatedAt = System.currentTimeMillis()))
        }
    }
}
