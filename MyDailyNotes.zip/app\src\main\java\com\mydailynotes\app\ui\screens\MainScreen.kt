package com.mydailynotes.app.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydailynotes.app.R
import com.mydailynotes.app.ui.components.AppTopBar
import com.mydailynotes.app.ui.screens.calendar.CalendarScreen
import com.mydailynotes.app.ui.screens.history.HistoryScreen
import com.mydailynotes.app.ui.screens.notes.NotesScreen
import com.mydailynotes.app.ui.screens.search.SearchScreen
import com.mydailynotes.app.ui.screens.settings.SettingsScreen
import com.mydailynotes.app.ui.screens.statistics.StatisticsScreen
import com.mydailynotes.app.ui.viewmodel.HistoryViewModel
import com.mydailynotes.app.ui.viewmodel.NoteViewModel
import com.mydailynotes.app.ui.viewmodel.TaskViewModel

enum class NavigationTab(val titleRes: Int, val icon: ImageVector) {
    CALENDAR(R.string.nav_calendar, Icons.Default.CalendarMonth),
    NOTES(R.string.nav_notes, Icons.Default.Description),
    SEARCH(R.string.search_hint, Icons.Default.Search),
    HISTORY(R.string.nav_history, Icons.Default.History),
    STATS(R.string.nav_stats, Icons.Default.BarChart),
    SETTINGS(R.string.nav_settings, Icons.Default.Settings)
}

@Composable
fun MainScreen(
    taskViewModel: TaskViewModel,
    noteViewModel: NoteViewModel,
    historyViewModel: HistoryViewModel
) {
    var selectedTab by remember { mutableStateOf(NavigationTab.CALENDAR) }
    val selectedDate by taskViewModel.selectedDate.collectAsState()

    Scaffold(
        topBar = {
            if (selectedTab == NavigationTab.CALENDAR) {
                AppTopBar(
                    selectedDate = selectedDate,
                    onTodayClick = { taskViewModel.jumpToToday() },
                    onSearchClick = { selectedTab = NavigationTab.SEARCH }
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                listOf(
                    NavigationTab.CALENDAR,
                    NavigationTab.NOTES,
                    NavigationTab.SEARCH,
                    NavigationTab.HISTORY,
                    NavigationTab.STATS,
                    NavigationTab.SETTINGS
                ).forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = stringResource(tab.titleRes)
                            )
                        },
                        label = {
                            Text(
                                text = when (tab) {
                                    NavigationTab.CALENDAR -> "التقويم"
                                    NavigationTab.NOTES -> "ملاحظات"
                                    NavigationTab.SEARCH -> "بحث"
                                    NavigationTab.HISTORY -> "السجل"
                                    NavigationTab.STATS -> "إحصاء"
                                    NavigationTab.SETTINGS -> "إعدادات"
                                },
                                fontSize = 10.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    ) { paddingValues ->
        when (selectedTab) {
            NavigationTab.CALENDAR -> CalendarScreen(viewModel = taskViewModel, modifier = Modifier.padding(paddingValues))
            NavigationTab.NOTES -> NotesScreen(viewModel = noteViewModel, modifier = Modifier.padding(paddingValues))
            NavigationTab.SEARCH -> SearchScreen(viewModel = taskViewModel, modifier = Modifier.padding(paddingValues))
            NavigationTab.HISTORY -> HistoryScreen(viewModel = historyViewModel, modifier = Modifier.padding(paddingValues))
            NavigationTab.STATS -> StatisticsScreen(viewModel = taskViewModel, modifier = Modifier.padding(paddingValues))
            NavigationTab.SETTINGS -> SettingsScreen(modifier = Modifier.padding(paddingValues))
        }
    }
}
