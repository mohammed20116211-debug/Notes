package com.mydailynotes.app.ui.screens.calendar

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydailynotes.app.R
import com.mydailynotes.app.data.model.Task
import com.mydailynotes.app.ui.components.ConfirmDialog
import com.mydailynotes.app.ui.components.EmptyStateView
import com.mydailynotes.app.ui.screens.task.AddEditTaskDialog
import com.mydailynotes.app.ui.screens.task.TaskDetailsDialog
import com.mydailynotes.app.ui.screens.task.TaskItemCard
import com.mydailynotes.app.ui.viewmodel.TaskViewModel
import com.mydailynotes.app.util.DateTimeUtils
import java.time.LocalDate

@Composable
fun CalendarScreen(
    viewModel: TaskViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDate by viewModel.selectedDate.collectAsState()
    val currentMonth by viewModel.selectedMonth.collectAsState()
    val tasksForDay by viewModel.tasksForSelectedDate.collectAsState()
    val datesWithTasks by viewModel.datesWithTasks.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var taskToEdit by remember { mutableStateOf<Task?>(null) }
    var taskToView by remember { mutableStateOf<Task?>(null) }
    var taskToDelete by remember { mutableStateOf<Task?>(null) }
    var showCompletedSection by remember { mutableStateOf(false) }

    val activeTasks = remember(tasksForDay) { tasksForDay.filter { !it.isCompleted } }
    val completedTasks = remember(tasksForDay) { tasksForDay.filter { it.isCompleted } }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = stringResource(R.string.add_task),
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Interactive Monthly Calendar
            item {
                MonthCalendarView(
                    currentMonth = currentMonth,
                    selectedDate = selectedDate,
                    datesWithTasks = datesWithTasks,
                    onDateSelected = { viewModel.selectDate(it) },
                    onPreviousMonth = { viewModel.previousMonth() },
                    onNextMonth = { viewModel.nextMonth() }
                )
            }

            // Summary Counter Strip
            item {
                TaskCounterStrip(
                    selectedDate = selectedDate,
                    totalCount = tasksForDay.size,
                    completedCount = completedTasks.size,
                    onJumpToToday = { viewModel.jumpToToday() }
                )
            }

            // Active Tasks List
            if (activeTasks.isEmpty() && completedTasks.isEmpty()) {
                item {
                    EmptyStateView(
                        title = stringResource(R.string.no_tasks_today),
                        subtitle = stringResource(R.string.no_tasks_today_hint),
                        actionButtonText = stringResource(R.string.add_task),
                        onActionClick = { showAddDialog = true },
                        modifier = Modifier.padding(top = 24.dp)
                    )
                }
            } else {
                items(activeTasks, key = { it.id }) { task ->
                    TaskItemCard(
                        task = task,
                        onToggleComplete = { isChecked ->
                            viewModel.toggleTaskCompletion(task, isChecked)
                        },
                        onPostponeToTomorrow = {
                            viewModel.postponeTaskToTomorrow(task)
                        },
                        onEdit = {
                            taskToEdit = task
                        },
                        onDelete = {
                            taskToDelete = task
                        },
                        onViewDetails = {
                            taskToView = task
                        }
                    )
                }

                // Completed Tasks Section
                if (completedTasks.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.AssignmentTurnedIn,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "${stringResource(R.string.completed_tasks)} (${completedTasks.size})",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    IconButton(onClick = { showCompletedSection = !showCompletedSection }) {
                                        Icon(
                                            imageVector = if (showCompletedSection) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null
                                        )
                                    }
                                }

                                AnimatedVisibility(visible = showCompletedSection) {
                                    Column {
                                        completedTasks.forEach { completedTask ->
                                            TaskItemCard(
                                                task = completedTask,
                                                onToggleComplete = { isChecked ->
                                                    viewModel.toggleTaskCompletion(completedTask, isChecked)
                                                },
                                                onPostponeToTomorrow = {
                                                    viewModel.postponeTaskToTomorrow(completedTask)
                                                },
                                                onEdit = { taskToEdit = completedTask },
                                                onDelete = { taskToDelete = completedTask },
                                                onViewDetails = { taskToView = completedTask }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Task Dialog
    if (showAddDialog) {
        AddEditTaskDialog(
            initialDate = selectedDate,
            onSave = { newTask ->
                viewModel.addTask(newTask)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }

    if (taskToEdit != null) {
        AddEditTaskDialog(
            initialDate = taskToEdit!!.startDate,
            taskToEdit = taskToEdit,
            onSave = { updatedTask ->
                viewModel.updateTask(updatedTask)
                taskToEdit = null
            },
            onDismiss = { taskToEdit = null }
        )
    }

    // View Details Dialog
    if (taskToView != null) {
        TaskDetailsDialog(
            task = taskToView!!,
            onEdit = {
                val t = taskToView!!
                taskToView = null
                taskToEdit = t
            },
            onPostponeToTomorrow = {
                viewModel.postponeTaskToTomorrow(taskToView!!)
                taskToView = null
            },
            onToggleComplete = {
                viewModel.toggleTaskCompletion(taskToView!, !taskToView!!.isCompleted)
                taskToView = null
            },
            onDismiss = { taskToView = null }
        )
    }

    // Delete Confirmation Dialog
    if (taskToDelete != null) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            message = stringResource(R.string.confirm_delete_task),
            confirmText = stringResource(R.string.delete_task),
            isDestructive = true,
            onConfirm = {
                viewModel.deleteTask(taskToDelete!!)
                taskToDelete = null
            },
            onDismiss = { taskToDelete = null }
        )
    }
}

@Composable
private fun TaskCounterStrip(
    selectedDate: LocalDate,
    totalCount: Int,
    completedCount: Int,
    onJumpToToday: () -> Unit
) {
    val isToday = selectedDate == LocalDate.now()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = DateTimeUtils.formatFullDate(selectedDate),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${stringResource(R.string.scheduled_tasks)}: $totalCount  •  ${stringResource(R.string.completed_tasks)}: $completedCount",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (!isToday) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                    .clickable(onClick = onJumpToToday)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.today),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
