package com.mydailynotes.app.ui.screens.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydailynotes.app.R
import com.mydailynotes.app.data.model.Category
import com.mydailynotes.app.data.model.Priority
import com.mydailynotes.app.data.model.Task
import com.mydailynotes.app.data.model.TaskStatus
import com.mydailynotes.app.ui.components.EmptyStateView
import com.mydailynotes.app.ui.screens.task.TaskDetailsDialog
import com.mydailynotes.app.ui.screens.task.TaskItemCard
import com.mydailynotes.app.ui.viewmodel.TaskViewModel

@Composable
fun SearchScreen(
    viewModel: TaskViewModel,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.filteredSearchResults.collectAsState()
    val filterCategory by viewModel.filterCategory.collectAsState()
    val filterPriority by viewModel.filterPriority.collectAsState()
    val filterStatus by viewModel.filterStatus.collectAsState()

    var taskToView by remember { mutableStateOf<Task?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 8.dp)
    ) {
        // Search Input Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text(stringResource(R.string.search_hint)) },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(16.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filters Horizontal Scroll Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Status Filters
            FilterChipItem(
                label = "الكل",
                isSelected = filterCategory == null && filterPriority == null && filterStatus == null,
                onClick = {
                    viewModel.setFilterCategory(null)
                    viewModel.setFilterPriority(null)
                    viewModel.setFilterStatus(null)
                }
            )

            TaskStatus.values().forEach { status ->
                FilterChipItem(
                    label = status.titleAr,
                    isSelected = filterStatus == status,
                    onClick = {
                        viewModel.setFilterStatus(if (filterStatus == status) null else status)
                    }
                )
            }

            // Category Filters
            Category.values().forEach { cat ->
                FilterChipItem(
                    label = cat.titleAr,
                    isSelected = filterCategory == cat,
                    onClick = {
                        viewModel.setFilterCategory(if (filterCategory == cat) null else cat)
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Results List
        if (searchResults.isEmpty()) {
            EmptyStateView(
                title = "لا توجد نتائج مطابقة",
                subtitle = "جرب البحث بكلمات أخرى أو تغيير خيارات التصفية.",
                icon = Icons.Default.Search,
                modifier = Modifier.padding(top = 40.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp, top = 8.dp)
            ) {
                items(searchResults, key = { it.id }) { task ->
                    TaskItemCard(
                        task = task,
                        onToggleComplete = { isChecked ->
                            viewModel.toggleTaskCompletion(task, isChecked)
                        },
                        onPostponeToTomorrow = {
                            viewModel.postponeTaskToTomorrow(task)
                        },
                        onEdit = {},
                        onDelete = { viewModel.deleteTask(task) },
                        onViewDetails = { taskToView = task }
                    )
                }
            }
        }
    }

    if (taskToView != null) {
        TaskDetailsDialog(
            task = taskToView!!,
            onEdit = { taskToView = null },
            onPostponeToTomorrow = {
                viewModel.postponeTaskToTomorrow(taskToView!!)
                taskToView = null
            },
            onToggleComplete = {
                viewModel.toggleTaskCompletion(taskToView!, !taskToView!!.isCompleted)
                taskToView = null
            },
            onDismiss = { taskToView = null }
        )
    }
}

@Composable
private fun FilterChipItem(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val text = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text = label, color = text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
