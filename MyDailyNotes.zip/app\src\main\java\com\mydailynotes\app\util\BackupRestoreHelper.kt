package com.mydailynotes.app.util

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonDeserializer
import com.google.gson.JsonPrimitive
import com.google.gson.JsonSerializer
import com.mydailynotes.app.data.local.DailyNotesDatabase
import com.mydailynotes.app.data.local.entity.HistoryEntity
import com.mydailynotes.app.data.local.entity.NoteEntity
import com.mydailynotes.app.data.local.entity.TaskEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.LocalTime

data class BackupData(
    val exportDate: String,
    val tasks: List<TaskEntity>,
    val notes: List<NoteEntity>,
    val history: List<HistoryEntity>
)

object BackupRestoreHelper {

    private val gson: Gson = GsonBuilder()
        .registerTypeAdapter(LocalDate::class.java, JsonSerializer<LocalDate> { src, _, _ -> JsonPrimitive(src.toString()) })
        .registerTypeAdapter(LocalDate::class.java, JsonDeserializer { json, _, _ -> LocalDate.parse(json.asString) })
        .registerTypeAdapter(LocalTime::class.java, JsonSerializer<LocalTime> { src, _, _ -> JsonPrimitive(src.toString()) })
        .registerTypeAdapter(LocalTime::class.java, JsonDeserializer { json, _, _ -> LocalTime.parse(json.asString) })
        .setPrettyPrinting()
        .create()

    suspend fun exportBackup(context: Context): Result<File> = withContext(Dispatchers.IO) {
        try {
            val db = DailyNotesDatabase.getDatabase(context)
            val tasks = db.taskDao().getAllTasks().first()
            val notes = db.noteDao().getAllNotes().first()
            val history = db.historyDao().getRecentHistory(100).first()

            val backup = BackupData(
                exportDate = LocalDate.now().toString(),
                tasks = tasks,
                notes = notes,
                history = history
            )

            val jsonString = gson.toJson(backup)
            val backupDir = File(context.getExternalFilesDir(null), "backups")
            if (!backupDir.exists()) backupDir.mkdirs()

            val backupFile = File(backupDir, "my_daily_notes_backup_${System.currentTimeMillis()}.json")
            backupFile.writeText(jsonString)

            Result.success(backupFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun importBackup(context: Context, jsonContent: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val backup = gson.fromJson(jsonContent, BackupData::class.java)
            val db = DailyNotesDatabase.getDatabase(context)

            if (backup.tasks.isNotEmpty()) {
                db.taskDao().insertAll(backup.tasks)
            }
            if (backup.notes.isNotEmpty()) {
                db.noteDao().insertAll(backup.notes)
            }
            if (backup.history.isNotEmpty()) {
                db.historyDao().insertAll(backup.history)
            }

            Result.success(backup.tasks.size + backup.notes.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
