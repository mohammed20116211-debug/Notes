package com.mydailynotes.app.util

import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

object DateTimeUtils {

    fun formatMonthHeader(yearMonth: YearMonth): String {
        val formatter = DateTimeFormatter.ofPattern("MMMM yyyy", Locale("ar"))
        return yearMonth.format(formatter)
    }

    fun formatFullDate(date: LocalDate): String {
        val formatter = DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy", Locale("ar"))
        return date.format(formatter)
    }

    fun formatShortDate(date: LocalDate): String {
        val formatter = DateTimeFormatter.ofPattern("d MMM", Locale("ar"))
        return date.format(formatter)
    }

    fun formatTime(time: LocalTime): String {
        val formatter = DateTimeFormatter.ofPattern("hh:mm a", Locale("ar"))
        return time.format(formatter)
    }

    fun formatDuration(minutes: Long): String {
        val hours = minutes / 60
        val remainingMinutes = minutes % 60
        return when {
            hours > 0 && remainingMinutes > 0 -> {
                val hourStr = if (hours == 1L) "ساعة" else if (hours == 2L) "ساعتان" else "$hours ساعات"
                "$hourStr و $remainingMinutes دقيقة"
            }
            hours > 0 -> {
                if (hours == 1L) "ساعة واحدة" else if (hours == 2L) "ساعتان" else "$hours ساعات"
            }
            else -> "$remainingMinutes دقيقة"
        }
    }

    /**
     * Generates a 6x7 grid (or dynamic row grid) of dates for a given YearMonth,
     * including padded days from previous and next months.
     */
    fun generateMonthDays(yearMonth: YearMonth): List<LocalDate?> {
        val firstDayOfMonth = yearMonth.atDay(1)
        val daysInMonth = yearMonth.lengthOfMonth()

        // Arabic week starts on Saturday (DayOfWeek.SATURDAY = 6)
        // Let's determine offset: Saturday -> 0, Sunday -> 1, Monday -> 2, Tuesday -> 3, Wednesday -> 4, Thursday -> 5, Friday -> 6
        val firstDayOfWeek = firstDayOfMonth.dayOfWeek
        val startOffset = when (firstDayOfWeek) {
            DayOfWeek.SATURDAY -> 0
            DayOfWeek.SUNDAY -> 1
            DayOfWeek.MONDAY -> 2
            DayOfWeek.TUESDAY -> 3
            DayOfWeek.WEDNESDAY -> 4
            DayOfWeek.THURSDAY -> 5
            DayOfWeek.FRIDAY -> 6
        }

        val daysList = mutableListOf<LocalDate?>()
        // Leading nulls (or padding)
        for (i in 0 until startOffset) {
            daysList.add(null)
        }
        // Month days
        for (day in 1..daysInMonth) {
            daysList.add(yearMonth.atDay(day))
        }
        // Trailing nulls to complete final week
        while (daysList.size % 7 != 0) {
            daysList.add(null)
        }
        return daysList
    }
}
